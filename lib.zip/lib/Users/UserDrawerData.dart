// ignore_for_file: file_names, prefer_const_constructors, avoid_print, use_super_parameters

import 'package:appointment/Login/LoginPage.dart';
import 'package:appointment/Users/Homepage.dart';
import 'package:appointment/Users/UserChatwithAdmin.dart';
import 'package:appointment/main.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

class UDrawerdata extends StatefulWidget {
  const UDrawerdata({Key? key}) : super(key: key);

  @override
  State<UDrawerdata> createState() => _UDrawerdataState();
}

class _UDrawerdataState extends State<UDrawerdata> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? currentUser;
  String name = "No user";
  String email = "No email signed in";
  String image = "https://via.placeholder.com/150"; // Default image URL
  bool isLoading = true; // State to track loading

  @override
  void initState() {
    super.initState();
    currentUser = _auth.currentUser;
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    if (currentUser != null) {
      try {
        // Fetch user data from Firestore
        final userDoc = await _firestore
            .collection("Users")
            .doc(currentUser!.uid)
            .get();

        if (userDoc.exists) {
          setState(() {
            name = userDoc['name'] ?? "No user";
            email = userDoc['Email'] ?? "No email signed in";
            image = userDoc['image'] ?? image; // Use default if image not found
          });
        } else {
          print("User document does not exist.");
        }
      } catch (e) {
        print("Error fetching user data: $e");
      } finally {
        setState(() {
          isLoading = false; // Stop loading after data fetch
        });
      }
    } else {
      print("No user is currently logged in.");
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _signOut() async {
    try {
      if (currentUser != null) {
        // Update user status in Firestore
        await _firestore
            .collection('Users')
            .doc(currentUser!.uid)
            .update({'isLoggedIn': false});

        // Sign out from Google and Firebase
        await _googleSignIn.signOut();
        await _auth.signOut();

        Get.snackbar("Sign Out", "User signed out successfully.");
        Get.offAll(LoginPage());
      } else {
        Get.snackbar("Info", "No user is currently signed in.");
      }
    } catch (e) {
      print("Error signing out: $e");
      Get.snackbar("Error", "Error signing out: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Drawer(
      child: isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: 30),
                  // CircleAvatar(
                  //   radius: 50,
                  //   backgroundImage: NetworkImage(image),
                  //   backgroundColor: Colors.transparent,
                  // ),
                  SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Name: $name",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Email: $email",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  Divider(color: Colors.grey),
                  buildDrawerItem("Home", Icons.home, () {
                    Get.off(UserDashboard());
                  }),
                  // buildDrawerItem("Cart", Icons.card_travel, () {
                  //   Get.off(CartPage());
                  // }),
                  buildDrawerItem(
                      "Order Status", Icons.notification_important_outlined,
                      () {
                    if (currentUser != null) {
                      // Get.off(OrderStatus(userId: currentUser!.uid));
                    } else {
                      Get.snackbar("Error", "User not logged in.");
                    }
                  }),
                  buildDrawerItem("Chat With Admin", Icons.chat, () {
                    if (currentUser != null) {
                      Get.to(UserConversationScreen(
                          userName: name, userId: currentUser!.uid));
                    } else {
                      Get.snackbar("Error", "User not logged in.");
                    }
                  }),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: Card(
                      elevation: 10,
                      child: ListTile(
                        title: Text("Dark Mode"),
                        trailing: Switch(
                          value: themeProvider.isDarkMode,
                          onChanged: (value) {
                            themeProvider.toggleTheme(); // Toggle dark mode
                          },
                        ),
                      ),
                    ),
                  ),
                  buildDrawerItem("Log Out", Icons.logout, _signOut),
                ],
              ),
            ),
    );
  }

  Widget buildDrawerItem(String title, IconData icon, Function() onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      child: Card(
        elevation: 10,
        child: ListTile(
          title: Text(title),
          leading: Icon(icon, color: Colors.red),
          onTap: onTap,
        ),
      ),
    );
  }
}
