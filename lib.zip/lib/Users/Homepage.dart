import 'package:appointment/Login/LoginPage.dart';
import 'package:appointment/Users/UserDrawerData.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class UserDashboard extends StatefulWidget {
  const UserDashboard({super.key});

  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final CollectionReference doctorsCollection =
      FirebaseFirestore.instance.collection('Doctors');
  final CollectionReference usersCollection =
      FirebaseFirestore.instance.collection('Users');

  @override
  void initState() {
    super.initState();
    updateLoginStatus();
  }

  Future<void> updateLoginStatus() async {
    try {
      User? currentUser = _auth.currentUser;
      if (currentUser != null) {
        await usersCollection.doc(currentUser.uid).update({'isLoggedIn': true});
      }
    } catch (e) {
      print("Failed to update login status: $e");
      Get.snackbar("Error", "Failed to update login status: $e",
          colorText: Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doctors List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {});
            },
          ),
        ],
      ),
      drawer: const Drawer(child: UDrawerdata()),
      body: StreamBuilder<QuerySnapshot>(
        stream: doctorsCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Failed to load data."));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No doctors found."));
          }

          final doctors = snapshot.data!.docs.map((doc) {
            return doc.data() as Map<String, dynamic>;
          }).toList();

          return GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10.0,
              mainAxisSpacing: 10.0,
              childAspectRatio: 1.0,
            ),
            itemCount: doctors.length,
            itemBuilder: (context, index) {
              final doctorData = doctors[index];
              return Card(
                elevation: 10,
                child: InkWell(
                  onTap: () {
                    // Navigate to doctor details page
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Text(
                          "${doctorData['doctorName'] ?? 'No Name'}",
                          style: const TextStyle(fontSize: 15),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5, top: 3),
                        child: Text(
                          "Specialty: ${doctorData['category'] ?? 'No Specialty'}",
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          _auth.signOut();
                          updateLoginStatus();
                          Get.to(LoginPage());
                        },
                        child: const Text("Appointment"),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
