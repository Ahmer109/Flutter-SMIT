import 'package:appointment/Admin/AddDoctor.dart';
import 'package:appointment/Admin/AdminChatPage.dart';
import 'package:appointment/Admin/AdminDashboard.dart';
import 'package:appointment/Admin/CurruntLoginUsers.dart';
import 'package:appointment/Admin/DoctorsList.dart';
import 'package:appointment/Admin/UsersList.dart';
import 'package:appointment/Login/LoginPage.dart';
import 'package:appointment/main.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

class Drawerdata extends StatefulWidget {
  const Drawerdata({Key? key}) : super(key: key);

  @override
  State<Drawerdata> createState() => _DrawerdataState();
}

class _DrawerdataState extends State<Drawerdata> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  String name = "No user";
  String email = "No email signed in";
  String image = "https://via.placeholder.com/150"; // Placeholder for no image
  bool isLoading = true; // Indicates whether data is being fetched

  @override
  void initState() {
    super.initState();
    _user = _auth.currentUser;
    if (_user != null) {
      _fetchUserData();
    }
  }

  // Fetch user data from Firestore
  Future<void> _fetchUserData() async {
    try {
      print("Fetching user data for UID: ${_user!.uid}");
      final userDoc = await _firestore.collection("Admin").doc(_user!.uid).get();

      if (userDoc.exists) {
        print("User document found: ${userDoc.data()}");
        setState(() {
          name = userDoc.data()?['name'] ?? "No user";
          email = userDoc.data()?['Email'] ?? "No email signed in";
          // Uncomment this if 'image' field is present in Firestore
          image = userDoc.data()?['image'] ?? "https://via.placeholder.com/150";
        });
      } else {
        print("No document found for UID: ${_user!.uid} in 'Admin' collection.");
        setState(() {
          name = "No user";
          email = "No email signed in";
        });
      }
    } catch (e) {
      print("Error fetching user data: $e");
      Get.snackbar("Error", "Failed to fetch user data: ${e.toString()}");
    } finally {
      setState(() {
        isLoading = false; // Stop loading after fetching
      });
    }
  }

  // Sign out function
  Future<void> _signOut() async {
    try {
      if (_user != null) {
        await _updateUserStatus(_user!.uid, false);
      }
      await _googleSignIn.signOut();
      await _auth.signOut();
      Get.snackbar("SignOut", "User signed out successfully.");
      Get.offAll(LoginPage());
    } catch (e) {
      Get.snackbar("Error", "Error signing out: ${e.toString()}");
    }
  }

  // Update user status in Firestore (logged out status)
  Future<void> _updateUserStatus(String userId, bool isLoggedIn) async {
    try {
      await _firestore.collection('users').doc(userId).update({'isLoggedIn': isLoggedIn});
    } catch (e) {
      Get.snackbar("Error", "Failed to update user status: ${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(),
            Divider(color: Colors.grey),
            _buildDrawerItem("Home", Icons.home, () {
              Get.off(AdminDashboard());
            }),
            _buildDrawerItem("Add Doctor", Icons.person_add_alt_1, () {
              Get.off(RegisterDoctor());
            }),
            // _buildDrawerItem("Accepted Orders", Icons.verified, () {
            //   Get.off(AcceptedOrders());
            // }),
            // _buildDrawerItem("Delivered Orders", Icons.delivery_dining_outlined, () {
            //   Get.off(DeliveredOrders());
            // }),
            // _buildDrawerItem("Orders Rejected", Icons.cancel, () {
            //   Get.off(DeclinedOrders());
            // }),
          // _buildDrawerItem("Users", Icons.people, () {
          //     Get.off(Userslist());
          //   }),
          _buildDrawerItem("Doctor", Icons.people, () {
              Get.off(DoctorsList());
            }),
            _buildDrawerItem("Chats", Icons.chat, () {
              Get.off(UserListScreen());
            }),
            
            // _buildDrawerItem("Logged-In Users", Icons.people, () {
          
            //     Get.off(UserLoggedinScreen());
              
            // }),
            // _buildDrawerItem("Add Category", Icons.category, () {
            //   Get.off(Adddishes());
            // }),
            _buildThemeSwitch(themeProvider),
            _buildDrawerItem("Log Out", Icons.logout, () {
              _signOut();
            }),
          ],
        ),
      ),
    );
  }

  // Header section of the drawer
  Widget _buildHeader() {
    return isLoading
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: CircularProgressIndicator(), // Show loader when loading
            ),
          )
        : Column(
            children: [
              SizedBox(height: 30),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "Name: $name",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "Email: $email",
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          );
  }

  // Drawer item widget
  Widget _buildDrawerItem(String title, IconData icon, Function onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      child: Card(
        elevation: 10,
        child: ListTile(
          title: Text(title),
          leading: Icon(icon, color: Colors.red),
          onTap: () => onTap(),
        ),
      ),
    );
  }

  // Dark mode switch
  Widget _buildThemeSwitch(ThemeProvider themeProvider) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Card(
        elevation: 10,
        child: SwitchListTile(
          title: Text("Dark Mode"),
          value: themeProvider.isDarkMode,
          onChanged: (value) {
            themeProvider.toggleTheme();
          },
        ),
      ),
    );
  }
}
