// ignore_for_file: prefer_const_constructors, file_names, unnecessary_to_list_in_spreads, sort_child_properties_last

import 'package:appointment/Admin/AdminDrawerData.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

// ignore: use_key_in_widget_constructors
class AdminDashboard extends StatefulWidget {
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final CollectionReference ordersCollection = FirebaseFirestore.instance.collection('Orders');

  @override
  void initState() {
    super.initState();
  }

  Future<void> updateOrderStatus(String orderId, String status) async {
    try {
      var orderData = await ordersCollection.doc(orderId).get();
      if (!orderData.exists) {
        Get.snackbar("Error", "Order not found");
        return;
      }

      var orderDetails = orderData.data() as Map<String, dynamic>;
      // ignore: unused_local_variable
      String dishNames = (orderDetails['items'] as List<dynamic>).map((item) => item['name']).join(', ');

      if (status == 'Delivered') {
        await FirebaseFirestore.instance.collection('DeliveredOrders').add({
          'userName': orderDetails['userName'],
          'userEmail': orderDetails['userEmail'],
          'userAddress': orderDetails['userAddress'],
          'items': orderDetails['items'],
          'totalPrice': orderDetails['totalPrice'],
          'timestamp': FieldValue.serverTimestamp(),
        });

        Get.snackbar("Success", "Order $orderId has been delivered and removed.");
        await ordersCollection.doc(orderId).delete();
      } else if (status == 'Declined') {
        await FirebaseFirestore.instance.collection('DeclinedOrders').add({
          'userName': orderDetails['userName'],
          'userEmail': orderDetails['userEmail'],
          'userAddress': orderDetails['userAddress'],
          'items': orderDetails['items'],
          'totalPrice': orderDetails['totalPrice'],
          'timestamp': FieldValue.serverTimestamp(),
        });

        Get.snackbar("Success", "Order $orderId has been rejected and removed.");
        await ordersCollection.doc(orderId).delete();
      } else {
        await ordersCollection.doc(orderId).update({'status': status});
        Get.snackbar("Success", "Order status updated to $status.");
      }
    } catch (e) {
      Get.snackbar("Failed to update order status", "$e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
      ),
      drawer: Drawer(child: Drawerdata()),
      body: SafeArea(
        child: StreamBuilder<QuerySnapshot>(
          stream: ordersCollection.orderBy('timestamp', descending: true).snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return Center(child: Text('No orders found.'));
            }

            var orders = snapshot.data!.docs;

            return ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                var orderData = orders[index].data() as Map<String, dynamic>;
                String orderId = orders[index].id;
                String status = orderData['status'] ?? 'Pending';

                return buildOrderCard(orderData, orderId, status);
              },
            );
          },
        ),
      ),
    );
  }

  Widget buildOrderCard(Map<String, dynamic> orderData, String orderId, String status) {
    var items = orderData['items'] as List<dynamic>;
    var timestamp = orderData['timestamp']?.toDate() ?? DateTime.now();
    double totalPrice = orderData['totalPrice'] ?? 0.0;

    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: buildOrderDetails(orderData),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildOrderItems(items),
            SizedBox(height: 4),
            Text('Total Price: ${totalPrice.toStringAsFixed(2)}'),
            Text('Ordered Time: ${timestamp.toLocal()}'),
            buildOrderActions(orderId, status),
          ],
        ),
      ),
    );
  }

  Column buildOrderDetails(Map<String, dynamic> orderData) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Name: ${orderData['userName']}'),
        Text('Email: ${orderData['userEmail']}'),
        Text('Address: ${orderData['userAddress']}'),
      ],
    );
  }

  Widget buildOrderItems(List<dynamic> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ...items.map((item) {
          return Text('Dish: ${item['name']} (Qty: ${item['quantity']})');
        }).toList(),
      ],
    );
  }

  Widget buildOrderActions(String orderId, String status) {
    if (status == 'Accepted') {
      return Center(
        child: ElevatedButton(
          onPressed: () => updateOrderStatus(orderId, 'Out for Delivery'),
          child: Text('Out for Delivery',
          style: TextStyle(color: Colors.white)),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
        ),
      );
    } else if (status == 'Out for Delivery') {
      return Center(
        child: ElevatedButton(
          onPressed: () => updateOrderStatus(orderId, 'Delivered'),
          child: Text('Delivered',
          style: TextStyle(color: Colors.white)),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
        ),
      );
    } else {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          ElevatedButton(
            onPressed: () => updateOrderStatus(orderId, 'Accepted'),
            child: Text('Accept', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
          ElevatedButton(
            onPressed: () => updateOrderStatus(orderId, 'Declined'),
            child: Text('Decline', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      );
    }
  }
}
