// ignore: file_names
import 'package:appointment/Admin/AdminConversationRoom.dart';
import 'package:appointment/Admin/AdminDrawerData.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Drawerdata(),
      ),
      appBar: AppBar(
        title: Text('User List',

        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('Users').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          final users = snapshot.data!.docs;

          return ListView.builder(
            shrinkWrap: true,
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];
              final userId = user.id; // User ID from document ID
              final userData = user.data() as Map<String, dynamic>; // Get user data as a map

              // Check if fields exist and assign default values if they don't
              final userName = userData.containsKey('name') ? userData['name'] : 'No name';
              final userEmail = userData.containsKey('Email') ? userData['Email'] : 'No email';
              final UserImage = userData.containsKey('image') ? userData['image'] : 'No image';

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      child: ListTile(
                        // leading: CircleAvatar(
                        //   backgroundImage: NetworkImage(UserImage),
                        // ),
                        title: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(userName),
                            Text(userEmail),
                          ],
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AdminConversationScreen(
                                userId: userId,
                                userName: userName,
                                UserImage: UserImage, // Pass the correct userImage
                      
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  // Divider(thickness: 1),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
