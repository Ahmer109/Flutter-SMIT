import 'package:appointment/Admin/AdminDrawerData.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class RegisterDoctor extends StatefulWidget {
  const RegisterDoctor({super.key});

  @override
  State<RegisterDoctor> createState() => _RegisterDoctorState();
}

class _RegisterDoctorState extends State<RegisterDoctor> {
  bool obscureText = true;
  final _formKey = GlobalKey<FormState>();

  // Controllers for the text fields
  final TextEditingController _doctorNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Dropdown list for categories
  String? _selectedCategory;
  final List<String> _categories = ["Cardiologist", "Neurologist", "Dentist", "Orthopedic"];

  // Firebase Auth instance
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Loading state
  bool _isLoading = false;

  // Function to register the doctor
  Future<void> _registerDoctor() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Create Firebase user with the provided email and password
        UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: _emailController.text,
          password: _passwordController.text,
        );

        // Get the user data from Firebase
        User? user = userCredential.user;

        if (user != null) {
          // Save the doctor's details in Firestore
          await _firestore.collection('Doctors').doc(user.uid).set({
            'doctorName': _doctorNameController.text,
            'email': _emailController.text,
            'category': _selectedCategory,
            'Password': _passwordController.text,
            'userType': 'Doctor', // Save user type as 'Doctor'
          });

          // Show success message
          Get.snackbar("Success", "Doctor registered successfully!", colorText: Colors.white);
          
          // Optionally, navigate to another page (like admin dashboard)
          // Get.offAll(AdminDashboard());

        }
      } catch (e) {
        Get.snackbar("Error", "Failed to register doctor: ${e.toString()}", colorText: Colors.white);
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Drawerdata(),
      ),
      appBar: AppBar(
        title: Text('Register Doctor'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Doctor Name TextField
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: _doctorNameController,
                  decoration: InputDecoration(
                    labelText: 'Doctor Name',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter doctor name';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 16),
        
              // Email TextField
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter email';
                    } else if (!RegExp(r"^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$").hasMatch(value)) {
                      return 'Please enter a valid email';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 16),
        
              // Password TextField
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  
                  controller: _passwordController,
                  obscureText: obscureText,
                  decoration: InputDecoration(
                    suffixIcon: IconButton(
                      onPressed:(){
                    setState(() {
                      obscureText= !obscureText;
                    });
                    }, 
                    icon: Icon(obscureText?Icons.visibility_outlined:Icons.visibility_off_outlined)) ,
                    labelText: 'Password',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter password';
                    } else if (value.length < 6) {
                      return 'Password must be at least 6 characters long';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 16),
        
              // Category Dropdown
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButtonFormField<String>(
                  value: _selectedCategory,
                  items: _categories.map((category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text(category),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedCategory = value;
                    });
                  },
                  decoration: InputDecoration(
                    labelText: 'Category',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.category),
                  ),
                  validator: (value) {
                    if (value == null) {
                      return 'Please select a category';
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 24),
        
              // Register Button
              _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : ElevatedButton(
                      onPressed: _registerDoctor,
                      child: Text('Register'),
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 15),
                        textStyle: TextStyle(fontSize: 18),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
