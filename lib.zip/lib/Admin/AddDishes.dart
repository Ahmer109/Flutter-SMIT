// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, sort_child_properties_last, non_constant_identifier_names, unused_field, unnecessary_string_interpolations, sized_box_for_whitespace, avoid_print, file_names

import 'dart:io';
import 'package:appointment/Admin/AdminDrawerData.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';


class Adddishes extends StatefulWidget {
  const Adddishes({super.key});

  @override
  State<Adddishes> createState() => _AdddishesState();
}

class _AdddishesState extends State<Adddishes> {
  var downloadLink = "";
  File? _image;
  final ImagePicker _picker = ImagePicker();
  final CollectionReference usersCollection =
      FirebaseFirestore.instance.collection('Category');

  var Categorycontroller = TextEditingController();
  TextEditingController price = TextEditingController();
  String? currentCategoryId;

  void imagesource() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return Container(
          // color: Colors.black,
          height: 150,
          child: Column(
            children: [
              Card(
                // color: Colors.white10,
                child: ListTile(
                  title: Text(
                    "Camera",
                    // style: TextStyle(color: Colors.white),
                  ),
                  leading: Icon(Icons.camera,),
                  //  color: Colors.white),
                  onTap: () {
                    pickimage(ImageSource.camera);
                    Navigator.pop(context);
                  },
                ),
              ),
              Card(
                // color: Colors.white10,
                child: ListTile(
                  leading: Icon(Icons.photo_library,),
                  //  color: Colors.white),
                  title: Text(
                    'Gallery',
                    // style: TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    pickimage(ImageSource.gallery);
                    Navigator.of(context).pop();
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> pickimage(ImageSource source) async {
    final PickedFile = await _picker.pickImage(source: source);
    if (PickedFile != null) {
      setState(() {
        _image = File(PickedFile.path);
      });
    }
  }

  Future<void> imagestorestorage() async {
    if (_image == null) return; // Ensure there is an image to upload

    try {
      FirebaseStorage storage = FirebaseStorage.instance;
      Reference storageref =
          storage.ref().child("Dish/${Categorycontroller.text}");
      UploadTask uploadTask = storageref.putFile(_image!);
      TaskSnapshot snapshot = await uploadTask;
      downloadLink = await snapshot.ref.getDownloadURL();
      print("Download URL: $downloadLink");
    } catch (e) {
      print("Error uploading image: $e");
    }
  }

  Future<void> Category(String name) async {
    if (name.isEmpty) {
      Get.snackbar("Error", "Please Enter Category Name",);
          // colorText: Colors.white);
    } else {
      var key = currentCategoryId ?? FirebaseDatabase.instance.ref('Category').push().key;
      var Categoryobj = {
        "name": name,
        "status": true,
        "CategoryKey": key,
        "image": downloadLink.isNotEmpty ? downloadLink : "", // Ensure the image link is set
        "price": price.text
      };

      if (downloadLink.isNotEmpty) {
        await usersCollection.doc(key).set(Categoryobj);
        Get.snackbar("Title", currentCategoryId == null ? "Added to Database" : "Updated Category", );
        // colorText: Colors.white);
        setState(() {
          _image = null; // Clear the image
          currentCategoryId = null; // Reset the ID
          downloadLink = ""; // Reset download link
        });
      } else {
        Get.snackbar("Error", "Image upload failed, try again.",);
            // colorText: Colors.white);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.black,
      appBar: AppBar(
        // iconTheme: IconThemeData(color: Colors.white),
        // backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  imagesource();
                },
                child: CircleAvatar(
                  radius: 50,
                  // backgroundColor: Colors.black,
                  backgroundImage: downloadLink.isNotEmpty 
                      ? NetworkImage(downloadLink) 
                      : (_image == null ? NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStOB26e6FqhS8YWtkvN0L3cbFpupGF5VN8XA&s") : FileImage(_image!)),
                ),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: TextField(
                controller: Categorycontroller,
                // cursorColor: Colors.white,
                // style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                    borderSide: BorderSide(color: Colors.orange),
                  ),
                  // labelStyle: TextStyle(color: Colors.white),
                  labelText: 'Enter Category Name',
                  // hintStyle: TextStyle(color: Colors.white),
                  suffixIcon: Icon(
                    Icons.dining_sharp,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: TextField(
                controller: price,
                // cursorColor: Colors.white,
                // style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                    borderSide: BorderSide(color: Colors.orange),
                  ),
                  // labelStyle: TextStyle(color: Colors.white),
                  labelText: 'Enter Dish Price',
                  // hintStyle: TextStyle(color: Colors.white),
                  suffixIcon: Icon(
                    Icons.attach_money,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              width: MediaQuery.of(context).size.width * 0.90,
              child: ElevatedButton(
                onPressed: () async {
                  String name = Categorycontroller.text;
                  if (currentCategoryId == null) {
                    await imagestorestorage(); // Call image storage first for new category
                  }
                  await Category(name); // Then save the category

                  // Clear the text controllers after saving
                  price.clear();
                  Categorycontroller.clear();
                },
                child: Text(
                  currentCategoryId == null ? "Add Category" : "Update Category",
                  style: TextStyle(color: Colors.black),
                ),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              ),
            ),
            SizedBox(height: 10),
            Column(children: [
              Text("Category",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              StreamBuilder<QuerySnapshot>(
                stream: usersCollection.snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No categories found.'));
                  }
                  final categories = snapshot.data!.docs;
                  return ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: categories.length,
                    itemBuilder: (context, index) {
                      final userData = categories[index].data() as Map<String, dynamic>;
                      return Card(
                        elevation: 10,
                        color: Colors.white10,
                        child: ListTile(
                          leading: CircleAvatar(
                            radius: 30,
                            backgroundImage: NetworkImage(userData['image'] ?? ""),
                          ),
                          title: Text(
                            "${userData['name'] ?? 'No Name'}",
                            style: TextStyle( fontSize: 18),
                          ),
                          subtitle: Text(
                            "PKR : ${userData['price'] ?? 'No Price'}",
                            style: TextStyle( fontSize: 20),
                          ),
                          trailing: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "Status:\n${userData['status'] ?? false}",
                                style: TextStyle(
                                     fontSize: 20),
                              ),
                              IconButton(
                                onPressed: () {
                                  setState(() {
                                    currentCategoryId = categories[index].id;
                                    Categorycontroller.text = userData['name'];
                                    price.text = userData['price'];
                                    downloadLink = userData['image']; // Set the image for editing
                                    _image = null; // Optionally clear the local image
                                  });
                                },
                                icon: Icon(Icons.edit, color: Colors.blue),
                              ),
                              IconButton(
                                onPressed: () async {
                                  await usersCollection.doc(categories[index].id).delete();
                                  Get.snackbar("Success", "Category deleted",
                                  //  colorText: Colors.white
                                   );
                                },
                                icon: Icon(Icons.delete, color: Colors.red),
                              ),
                            ],
                          ),
                          onTap: () {},
                        ),
                      );
                    },
                  );
                },
              )
            ]),
          ],
        ),
      ),
    );
  }
}
